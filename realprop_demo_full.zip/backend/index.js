
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3002;

app.get('/api/immobili', (req, res) => {
  res.json([
    { id: 1, indirizzo: "Via Roma 23", proprietario: "Mario Bianchi", agenzia: "ReCasa Milano" }
  ]);
});

app.listen(PORT, () => {
  console.log(`Backend RealProp attivo su http://localhost:${PORT}`);
});
